
#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sstream>
#include <iostream>

std_msgs::String msgrev;
std::string msgrev_new;
std::string msgrev_new2;

void chatterCallback(const std_msgs::String::ConstPtr& msg)
{
  std::stringstream ss;
  std::stringstream ss_new;
  
  ss << msg->data; //putting message obtained from topic /team_abhiyaan into string stream ss
  msgrev_new= ss.str();
  msgrev_new2.assign(msgrev_new.rbegin(), msgrev_new.rend());//reversing the string message
  ss_new << msgrev_new2;
  msgrev.data = ss_new.str();
 
}

int main(int argc, char **argv)
{
  
  ros::init(argc, argv, "reverser");

  ros::NodeHandle n;

  ros::Publisher abhiyaan_pub = n.advertise<std_msgs::String>("/naayihba_maet", 1000);
  ros::Subscriber sub = n.subscribe("team_abhiyaan", 1000, chatterCallback);


  ros::Rate loop_rate(10);

  int count = 0;
  while (ros::ok())
  {

   
    std_msgs::String msg;

    ROS_INFO("%s\n", msgrev.data.c_str());

    abhiyaan_pub.publish(msgrev);

    ros::spinOnce();

    loop_rate.sleep();

    ++count;
  }


  return 0;
}

