#include <cstdlib> 
#include <iostream> 
 
#include "ros/ros.h" 
#include "geometry_msgs/Twist.h" 
#include "geometry_msgs/Pose2D.h" 
#include "turtlesim/Pose.h" 
 
using namespace std;
 

geometry_msgs::Twist velCommand; 
geometry_msgs::Pose2D current; 
geometry_msgs::Pose2D desired; 

 

void setup() {

   

  velCommand.linear.x = 0.5; //initial motion of turtle2
  velCommand.linear.y = 0.5;
  velCommand.linear.z = 0.0;
  velCommand.angular.x = 0.0;
  velCommand.angular.y = 0.0;
  velCommand.angular.z = 0.0;
}
 

double getDistanceToGoal() {
return (sqrt((desired.x - current.x)*(desired.x - current.x) + (desired.y - current.y)*(desired.y - current.y)));;//distance between turtles 1 and 2
}

double cos_a(){
 return abs(desired.x - current.x)/getDistanceToGoal();//cosine of angle made by line joining both turtles with the x-axis
 }
 
 double sin_a(){
 return abs(desired.y - current.y)/getDistanceToGoal();//sine of angle made by line joining both turtles with the x-axis
 }

void setVelocity() {
 
  //I've applied the concept of gravitational force here by making change in velocity inversely proportional to distance between turtles squared:
    velCommand.linear.x = velCommand.linear.x = velCommand.linear.x +(desired.x - current.x)/abs(desired.x - current.x)*(1/(getDistanceToGoal()*getDistanceToGoal()))*cos_a();
    
    velCommand.linear.y = velCommand.linear.y = velCommand.linear.y +(desired.y - current.y)/abs(desired.y - current.y)*(1/(getDistanceToGoal()*getDistanceToGoal()))*sin_a();
  
}
 

void updatePose(const turtlesim::PoseConstPtr &currentPose) {//constantly updates position of turtle2
  current.x = currentPose->x;
  current.y = currentPose->y;
  current.theta = currentPose->theta;
}
 
void getPose(const turtlesim::PoseConstPtr &currentPose) {
  desired.x = currentPose->x;
  desired.y = currentPose->y;
  desired.theta = currentPose->theta;
}
 
int main(int argc, char **argv) {
 
  setup();  
 

  ros::init(argc, argv, "go_to_goal_x");
     
  
  ros::NodeHandle node;
 

  ros::Subscriber currentPoseSub =
    node.subscribe("/turtle2/pose", 0, updatePose);
    
    ros::Subscriber currentPoseSub2 =
    node.subscribe("/turtle1/pose", 0, getPose);
 

  ros::Publisher velocityPub =
    node.advertise<geometry_msgs::Twist>("/turtle2/cmd_vel", 0);

  ros::Rate loop_rate(10); 
 
 
  while (ros::ok()) {
 
   
    ros::spinOnce();
 
    setVelocity();
 
    velocityPub.publish(velCommand);
 
    loop_rate.sleep();
  }
 
  return 0;
}
